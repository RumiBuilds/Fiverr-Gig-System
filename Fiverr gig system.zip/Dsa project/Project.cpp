#include<iostream>
#include<string.h>
#include<windows.h>
#include<iomanip>
#include<conio.h>
#include<fstream>

using namespace std;

struct profile
{
	string name,country;
	int emplooyees,orders;
	float rating;
	
};

struct node
{
	profile data;
	node *child;
	node *sibling;
};

class n_ary
{
	node *root;
	public:
		int else_count;
		n_ary():root(NULL),else_count(0)
		{
		}
/****************************************************************************
            Insertion Function
****************************************************************************/ 
		void insert()
		{
			node *ptr = new node;
			cout<<"\n\nEnter your name    : ";
			getline(cin,ptr->data.name);
			cout<<"Enter your country : ";
			getline(cin,ptr->data.country);
			cout<<"Enter your rating  : ";
			cin>>ptr->data.rating;
			ptr->data.emplooyees=0;
			ptr->data.orders=0;
			ptr->child=NULL;
			ptr->sibling=NULL;
			/******************************************************
			      if no node is present
			******************************************************/
			if(root==NULL)
			 root=ptr; 
			/******************************************************
			      if root node has been created
			******************************************************/
			else
			{
				node *child_insert=root;          //child inserter
				else_count++;
				if(else_count==1)      //To make sure that second node is first node's child not sibling
				{
					child_insert->child=ptr;
					child_insert->data.emplooyees++;
				}
				else
				{
				    /************************************************************
			             A user can only work under the root node or root's child
			        ************************************************************/	
					string choice;
					cout<<"\nAs whose Emplooyee do you want to work as (Case Sensitive): "<<endl;
					node *show=root;
					cout<<show->data.name<<"\t"<<show->data.emplooyees<<endl;
					show=root->child;
					/************************************************************
			             Will Display Eligible User Under Which A User Can Work
			        ************************************************************/	
					while(show!=NULL)
					{
						if(show->data.emplooyees<1)
						  cout<<show->data.name<<"\t"<<show->data.emplooyees<<endl;
						show=show->sibling;
					}
					cin>>choice;
					node * check=root;
					int pointer_shifter_1=0;    //for child to sibling manuver
					int res;          //will store the result of comparison
					/************************************************************
			             All the comparison in done here
			        ************************************************************/	
					while(check!=NULL)
					{
					    res=choice.compare(check->data.name);
						if(res==0)
							break;
						if(pointer_shifter_1==0)
						   check=check->child;
						else
						   check=check->sibling;
						pointer_shifter_1++;
					}
					int pointer_shifter_2=0;    //for child to sibling manuver
					if(res!=0)
					 cout<<"\nNo such member exist";
					/************************************************************
			            IF a user want to work under the owner
			        ************************************************************/
					else if(check==root)
					{
						node * temp=root;
						do
						{
							if(pointer_shifter_2==0)
						      temp=temp->child;
						    else
						      temp=temp->sibling;
						  pointer_shifter_2++;
						}while(temp->sibling!=NULL);
						temp->sibling=ptr;
						root->data.emplooyees++;
					}
					/************************************************************
			             IF a user wants to work under an Emplooyee 
			        ************************************************************/
					else
					{
						  check->child=ptr;
						  check->data.emplooyees++;
						  root->data.emplooyees++;	
					}
				}
			}
		
		}
		void load()
		{
			cout<<"\n\n\n\t\t\t\t\t\t\t\t\t\t  Sit Tight FreeLancer is Working On Your Project\n\n";
            char a=177, b=219;
            cout<<"\t\t\t\t\t\t\t\t\t\t";
            for (int i=0;i<=50;i++)
              cout<<a;
            cout<<"\r";
            cout<<"\t\t\t\t\t\t\t\t\t\t";
            for (int i=0;i<=50;i++)
            {
               cout<<b;
               Sleep(200); 
            }
		}
		void specifics(node *ptr)
		{
			cout<<endl;
			cout<<"\nName             : "<<ptr->data.name;
			cout<<"\nCountry          : "<<ptr->data.country;
			cout<<"\nRating           : "<<ptr->data.rating;
			cout<<"\nEmplooyees       : "<<ptr->data.emplooyees;
			cout<<"\nOrders Completed : "<<ptr->data.emplooyees;
			
		}
/****************************************************************************
            Display Function
****************************************************************************/ 
		void display()
		{
			system("cls");
			node *disp=root;
			if(disp!=NULL)
			{
			   cout<<"\n                                              -----------------------------"<<endl;
			   cout<<"                                                "<<"Gig's Owner";
			   cout<<"\n                                              -----------------------------"<<endl;
			   specifics(disp);          //Gig Owner
			   if(disp->child!=NULL)
			   {
			     cout<<"\n\n                                              -----------------------------"<<endl;
			     cout<<"                                                "<<disp->data.name<<"'s Emplooyees";
			     cout<<"\n                                              -----------------------------"<<endl;
			     disp=disp->child;
			     specifics(disp);        //First Child
			     if(disp->child!=NULL)  //First Child's Child
			     {
				     cout<<"\n\n-----------------------------"<<endl;
				     cout<<disp->data.name<<"'s Emplooyee";
				     cout<<"\n-----------------------------"<<endl;
			         specifics(disp->child);
			         cout<<"\n-----------------------------"<<endl;
			     }
			     if(disp->sibling!=NULL)
			     {
			       disp=disp->sibling;
	   		       while(disp!=NULL)     //Rest of the Childs
			       {
				     specifics(disp);
				     node *sub_child=disp->child;
				     if(sub_child==NULL)
				         {
						 }
				     else                     //Rest of the Child's Childs
				     {
					     cout<<"\n\n-----------------------------"<<endl;
				         cout<<disp->data.name<<"'s Emplooyee";
				         cout<<"\n-----------------------------"<<endl;
					     while(sub_child!=NULL)
					     {
						     specifics(sub_child);
						     sub_child=sub_child->sibling;
						     cout<<"\n-----------------------------"<<endl;
					     }
				     }
				     disp=disp->sibling;
			       }
			     }
		        }
	       }
	       else
	         cout<<"\n\n\n*****NO Gig Exist*****";
		}
/****************************************************************************
            Order Taking Function
****************************************************************************/ 
		void orders()
		{
			display();
			bool flag=0;
			string name;
			cout<<"\n\nTo whom you want to place an order? Enter Name (Case Sensitive) : ";
			cin>>name;
			int pointer_shifter=0;
			node *order=root;
            if(name==order->data.name)
            {
            	order->data.orders++;
            	load();
            	flag=1;
			}
			else
			{
			    if(order->child!=NULL)
			    {
			    	if(pointer_shifter==0)
			    	{
			    		pointer_shifter++;
			    		order=order->child;
			    		if(name==order->data.name)
			    		{
			    			order->data.orders++;
			    			load();
			    			flag=1;
						}
						else
						{
							if(order->child!=NULL && name==order->child->data.name)
							{
								order->child->data.orders++;
								load();
								flag=1;
							}
						}
					}
					else
					{
					  while(order!=NULL)
					  {
					  
						order=order->sibling;
						if(name==order->data.name)
						{
							order->data.orders++;
							load();
							flag=1;
						}
						else
						{
							if(name==order->child->data.name && order->child!=NULL)
							{
								order->child->data.orders++;
								load();
								flag=1;
							}
						}
					  }
					}
				}
			}
		   if(flag==0)
		   	  cout<<"\n\n\t\t\t\t\t\t\t\t\t\t ***** No such Emplooyee exist ***** (Incorrect name) ";
		   else
		   	  cout<<"\n\n\t\t\t\t\t\t\t\t\t   Congratulations! "<<name<<" has Successfully Completed Your Order ";
		}
/****************************************************************************
            Deletion Function
****************************************************************************/ 
		void del()
		{
			del_loop:
			bool flag=0;
			string opt;
			display();
			cout<<"\n\nWhich Seller do you want to remove Enter Name (Case Sensitive): ";
			cin>>opt;
            int manuver=0;
            node *del_p=root;
            node *prev=root;
            if(opt==del_p->data.name)
            {
            	cout<<"\n\n*****Are you sure! This action will delete the whole Gig***** (y/n) : \n";
            	char ch=getch();
            	if(ch=='y'||ch=='Y')
            	{
            		flag=1;
            		node *temp=del_p;
            		del_p=root=NULL;
            		delete temp;
				}
				else
				{
					cout<<"\n\nChoose another one !";
					goto del_loop;
				}
			}
			else
			{
			  while(flag==0)
			  {
				
				if(manuver==0)
				{
					del_p=del_p->child;
					if(opt==del_p->data.name)
					{
						if(del_p->sibling!=NULL)
						{
							flag=1;
							node* temp=del_p;
							prev->child==del_p->sibling;
							del_p=NULL;
							delete temp;
						}
						else
						{
							flag=1;
							node *temp=del_p;
							prev->child=NULL;
							del_p=NULL;
							delete temp;
						}
					}
					else
				    {
					  if(del_p->child!=NULL && opt==del_p->child->data.name)
					  {
					  	flag=1;
					  	node *temp=del_p->child;
					  	del_p->child=NULL;
					  	delete temp;
					  }
				    }
			    }
				else
				{
					prev=del_p;
					del_p=del_p->sibling;
					if(opt==del_p->data.name)
					{
						if(del_p->sibling!=NULL)
						{
							flag=1;
							node *temp=del_p;
							prev->sibling=del_p->sibling;
							del_p=NULL;
							delete del_p;
						}
						else
						{
							flag=1;
							node *temp=del_p;
							prev->sibling=NULL;
							del_p=NULL;
							delete temp;
						}
					}
					else
					{
						if(opt==del_p->child->data.name)
						{
							flag=1;
							node *temp=del_p->child;
							del_p->child=NULL;
							delete temp;
						}
					}
				}
				manuver++;
		      }  
			}
			
		   if(flag==0)
		   	  cout<<"\n\n***** No such Emplooyee exist ***** (Incorrect name) ";
		   else
		   	  cout<<"\n\n"<<opt<<" Successfully Deleted !!! ";
		}
};

/****************************************************************************
            Welcome Function
****************************************************************************/          
void welcome()
{
	system("cls");
	cout <<"\n\n\n									 ";
	for (int j = 0; j < 60; j++)
	{
		cout << "_";
		Sleep(3);
	}
	
	cout << endl<<endl;
	cout << setw(20) << "											Welcome to Fiverr Company Gig System " << endl;
	cout << setw(20) << "											Helping freelancers to work as team  " << endl;
	cout <<"									 ";
	for (int j=0;j<60;j++)
	{
		cout << "_";
		Sleep(10);
	}
	Sleep(500);
	cout<<endl<<endl<<endl;
}

void draw_main()
{
	cout<<"\n\n****************************************************************************";
	cout<<"\n                                 MAIN MENU                                   ";
	cout<<"\n****************************************************************************";
}

void draw_admin()
{
	cout<<"\n\n****************************************************************************";
	cout<<"\n                                 ADMIN MENU                                  ";
	cout<<"\n****************************************************************************";
}

void draw_buyer()
{
	cout<<"\n\n****************************************************************************";
	cout<<"\n                                 BUYER MENU                                  ";
	cout<<"\n****************************************************************************";
}

char back_menu()
{
	char ch;
	cout<<"\n\nDo you want to repeat the process (y/n) : \n";
	ch=getch();
	return ch;
}

/****************************************************************************
            Password Function
****************************************************************************/ 
bool password()
{
	pass_menu:
	char ch;
    cout<<"\n\n\nWhich action do you want to perform ?";
    cout<<"\n(1) Register  (2) Login  (3) Exit \n"<<endl;
    ch=getch();
    switch(ch)
    {
    	case'1':
    		{
    			loop:
    			ofstream  file("password.txt",ios::app);
                if(!file.is_open())
                  cout<<"\n*****Error Loading File*****";
                else
                {
                	string name,password;
                	cout<<"\nEnter a Username (Only First Name) : ";
                	getline(cin,name);
                	file<<name<<'\n';
                	cout<<"\nEnter a Password : ";
                    getline(cin,password);
                    file<<password;
                    file.close();
                    char option;
                    cout<<"\nDo you want to perform Registration again (y/n) : ";
					ch=getch();
					if(option=='Y'||option=='y')
					  goto loop;
					else
					  goto pass;
				}
    			break;
			}
		case'2':
				{
					pass:
					ifstream file("password.txt");
					if(!file.is_open())
					   cout<<"\n*****Error Loading File*****";
					else
					{
						string un,p,f_un,f_p;
						cout<<"\nEnter your Username : ";
						getline(cin,un);
						cout<<"Enter your Password : ";
						/*char asterik;
						asterik=getch();
						p.push_back(asterik);
						while(asterik!=13)
						{
							p.push_back(asterik);
							cout<<"*";
							asterik=getch();
						}*/
						getline(cin,p);
						while(!file.eof())
						{
						  getline(file,f_un,'\n');
						  getline(file,f_p,'\n');
						  if(f_un==un)
						      break;
					    }
						file.close();
						if(f_un==un&&f_p==p)
						{
							cout<<"\n\n                                       ---------------------------------------------------------";
							cout<<"\n                                                         Successfully Logged In";
							cout<<"\n                                       ---------------------------------------------------------";
							return 1;
						}
						else
						{
						    cout<<"\n\n                                       ********************************************************";
							cout<<"\n                                                   Error, Incorrect (Username/Password)";
							cout<<"\n                                       ********************************************************";
							cout<<"\n\nDo you want to try again (y/n) : ";
							char choice;
							choice=getch();
							if(choice=='y'||choice=='Y')
							  goto pass;
							else
							  return 0;
						}
					}
					break;
				}
			case'3':
					{
						return 0;
						break;
					}
			default:
					{
						cout<<"\n*******Invalid Choice Taking you back to Password Menu*******";
						goto pass_menu; 
						break;
					}
	}
   
}


int main()
{
	n_ary obj;
    char ch;
    bool ignore=0;
	do
	{
		main_loop:
	    welcome();
	    draw_main();
		char choice; 	
	    cout<<"\nHow do you want to proceed ?";
	    cout<<"\n(1) Seller  (2) Buyer  (3) Quit\n";
	    choice=getch();
	    switch(choice)
	    {
	    	case'1':
	    	{
	    		//bool check= password();
	    		bool check= 1;
	    		if(check==1)
	    		{
	    			admin_loop:
	    			system("cls");
	    			draw_admin();
	    			cout<<"\n\n\nWhich operation do you want to perform ?";
	    			cout<<"\n(1) Insertion  (2) Deletion  (3) Display  (4) Main Menu  (5) Exit\n";
	    			char ch;
	    			ch=getch();
	    			switch(ch)
	    			{
	    				case '1':
	    				{
						
	    					char ret;
	    					obj.insert();
	    					cin.ignore();
	    					ret = back_menu();
	    					if(ret=='Y'||ret=='y')
	                         goto admin_loop;
	                        else
	                         goto main_loop;
	    				    break;
	    			     }
	    				case '2':
	    				 {
					        if(ignore==0)
					        {
	    					  bool check=password();
	    					  if(!check)
	    					   { 
	    						  cout<<"\n\n!!!!! Only Admins Can Delete The Record";
	    						  cout<<"\nTaking You back to the Main Menu";
	    						  Sleep(300);
	    						  goto main_loop;
							   }
							   else
							   {
							   	 ignore=1;
							   	 obj.del();
							   	 cin.ignore();
							   }
						    }
							else
							{
								obj.del();
								cin.ignore();
							}
	    					char ret_1;
	    					ret_1 = back_menu();
	    					if(ret_1=='Y'||ret_1=='y')
	                         goto admin_loop;
	                        else
	                         goto main_loop;
	    					break;
	    			     }
	    				case '3':
	    				 {
							
	    					obj.display();
	    					char ret_2;
	    					ret_2 = back_menu();
	    					if(ret_2=='Y'||ret_2=='y')
	                         goto admin_loop;
	                        else
	                         goto main_loop;
	    					break;
	    			     }
	    				case '4':
	    					goto main_loop;
	    					break;
	    				case '5':
	    					exit(1);
	    					break;
	    				default:
	    					char a;
	    					cout<<"\n****Invalid Input**** Bringing you back to Admin Menu : ";
	    					goto admin_loop;
	    					break;
					}
				}
			  break;
		    }
		    case'2':
		    	{
		    		buyer_loop:
		    		system("cls");
		    		char opt;
		    		draw_buyer();
		    		cout<<"\n\n\nWhich Action do you want to Perform ? ";
		    		cout<<"\n(1) Placing Order  (2) Displaying Sellers  (3) Main Menu  (4) Exit "<<endl;
		    		opt=getch();
		    		switch(opt)
		    		{
		    			case'1':
		    				{
		    		          char opt_1;
		    		          draw_buyer();
		    		          obj.orders();
		    		          cin.ignore();
		    		          opt_1=back_menu();
		    		          if(opt_1=='Y'||opt_1=='y')
		    		           goto buyer_loop;
		    		          else
		    		           goto main_loop;
		    				  break;
							}
						case'2':
							{
								obj.display();
								char opt_2;
							    opt_2=back_menu();
		    		            if(opt_2=='Y'||opt_2=='y')
		    		              goto buyer_loop;
		    		            else
		    		              goto main_loop;
								break;
							}
						case'3':
							{
								goto main_loop;
								break;
							}
						case'4':
							{
								exit(1);
								break;
							}
					
					}
				}
	    	case'3':
	    		{
	    			exit(1);
	    			break;
				}
			default:
				{
					cout<<"\n****Invalid Choice****";
					goto main_loop;
					break;
				}
		}
		cout<<"\nDo you want to repeat the process (y/n) : ";
		ch=getch();
	}while(ch=='y'||ch=='Y'); 
	return 0;
}
